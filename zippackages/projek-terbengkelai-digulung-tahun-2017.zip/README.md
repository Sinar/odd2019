### Projek Perumahan Terbengkalai Yang Telah Digulung

* Source: http://www.data.gov.my/data/ms_MY/dataset/projek-perumahan-terbengkalai-yang-telah-digulung

Projek Perumahan Terbengkalai Yang Telah Digulung
Set data ini menerangkan tentang projek perumahan terbengkalai yang telah digulung



