JPS PULAU PINANG
=================
From FOIE Filed by Sinar Project in 2016

LAPORAN PENCEMARAN SUNGAI KAWASAN SEBERANG PERAI SELATAN (SPS)
=====================================
MPSP - Majlis Perbandaran Seberang Perai
JAS- Jabatan Alam Sekitar
JPS - Jabatan Pengairan dan Saliran

LAPORAN PENCEMARAN SUNGAI KAWASAN DAERAH BARAT DAYA (DBD)
=======================================
JAS- Jabatan Alam Sekitar
JPS - Jabatan Pengairan dan Saliran

LAPORAN PENCEMARAN SUNGAI KAWASAN DAERAH TIMUR LAUT (DTL)
============================================
JAS - Jabatan Alam Sekitar
JPS SPT - Jabatan Pengairan dan Saliran Seberang Perai Tengah
IWK - Indah Water Konsortium
SPAN - Suruhanjaya Perkhidmatan Air Negara
MBPP- Majlis Bandaraya Pulau Pinang
JPS - Jabatan Pengairan dan Saliran

LAPORAN PENCEMARAN SUNGAI KAWASAN DAERAH SEBERANG PERAI TENGAH (SPT)
=============================================

LAPORAN PENCEMARAN SUNGAI KAWASAN SEBERANG PERAI UTARA (SPU)
=====================================
MPSP - Majlis Perbandaran Seberang Perai
SPU - Seberang Perai Utara
IADA- Kawasan Pembangunan Pertanian Bersepadu


